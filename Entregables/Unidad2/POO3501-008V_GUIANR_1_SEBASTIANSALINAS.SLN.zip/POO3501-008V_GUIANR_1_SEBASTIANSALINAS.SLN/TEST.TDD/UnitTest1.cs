﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TEST.TDD
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
