﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Layer.Backend.MathCalculation.Random;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.Backend.MathCalculation.Random.Tests
{
    [TestClass()]
    public class RandomMakerTests
    {
        [TestMethod()]
        public void GetRandomValuesByLimitsTest()
        {
            Assert.Fail();
        }
    }
}