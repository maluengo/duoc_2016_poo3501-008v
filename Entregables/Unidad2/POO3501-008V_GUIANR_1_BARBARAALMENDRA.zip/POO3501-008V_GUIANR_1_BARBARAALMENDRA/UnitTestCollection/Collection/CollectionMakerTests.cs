﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Layer.Backend.MathCalculation.Collection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.Backend.MathCalculation.Collection.Tests
{
    [TestClass()]
    public class CollectionMakerTests
    {
        [TestMethod()]
        public void GetRandomCollectionByParameterTest()
        {
           
        }
    }
}