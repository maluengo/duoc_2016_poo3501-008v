﻿namespace Layer.Backend.MathCalculation.Entities.Dto
{
    public class NumbersDto
    {
        public int Number { get; set; }
        public int Index { get; set; }
    }
}
